﻿
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace Dsf.VCOP.ServiceTests.Setup
{
    class DBConnection
    {
        public static SqlDataReader DataReader(String sp)
        {
            string connetionString = null;
            SqlConnection connection;
            SqlCommand command;
            SqlDataReader dataReader;

            connetionString = Settings.ConnectionString;

            connection = new SqlConnection(connetionString);
            try
            {
                connection.Open();
                command = new SqlCommand(sp, connection);
                dataReader = command.ExecuteReader();


            }
            catch (Exception)
            {
                throw new Exception("Could not connect to db");
            }
            return dataReader;
        }
    }
}
