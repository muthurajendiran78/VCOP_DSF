﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Dsf.VCOP.ServiceTests.Setup
{
    public static class Login
    {
        static string token;
        public static async Task<string> GenerateMemberServiceToken(string authkey, string authurl, string request)
        {

            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Add("Authorization", authkey);
            //var byteArray = Encoding.ASCII.GetBytes("0oap2yxmqcSByiruG0h7:pqcdurZ9lvUoN06fMvjkMA5Vu0Pd8TDTXYcxHtf7");
            //client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));
            HttpContent content = new StringContent(request, Encoding.UTF8, "application/x-www-form-urlencoded");
            if (token == null)
            {
                Task<HttpResponseMessage> result = client.PostAsync(authurl, content);
                String response = await result.Result.Content.ReadAsStringAsync();

                string[] str = response.Split(',');
                foreach (string checkToken in str)
                {
                    if (checkToken.Contains("access_token"))
                    {
                        string[] splittoken = checkToken.Split(':');
                        token = splittoken[1].Replace('"', ' ');
                    }
                }
            }
            return "Bearer " + token.Trim();
        }

        internal static IDictionary<string, object> GetMemberServiceUserTokenforClubplus()
        {
            return new Dictionary<string, object> { { "Authorization", GenerateMemberServiceToken(Settings.AuthkeyforClubplus, Settings.AuthorizationUrlClubplus, Settings.MemberServiceTokenRequestforClubplus).Result } };

        }

        public static IDictionary<string, object> GetMemberServiceUserToken()
        {
            return new Dictionary<string, object> { { "Authorization", "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IjQ2Rnpfc2hCV3JWYUtCaEJtenZCSm0tcmt3MCIsImtpZCI6IjQ2Rnpfc2hCV3JWYUtCaEJtenZCSm0tcmt3MCJ9.eyJpc3MiOiJodHRwOi8vaWRzcnYtdHN0Lm9yaWVudGNhcGl0YWwubG9jYWwvb2lkYyIsImF1ZCI6Imh0dHA6Ly9pZHNydi10c3Qub3JpZW50Y2FwaXRhbC5sb2NhbC9vaWRjL3Jlc291cmNlcyIsImV4cCI6MTYxNDU5MDgzMywibmJmIjoxNjE0NTg3MjMzLCJjbGllbnRfaWQiOiJsaW5rZ3JvdXAuZnVuZGFkbWluLm1lbWJlcmNlbnRyZS5jbGllbnRjcmVkZW50aWFscy52Y29wIiwibGlua2dyb3VwLmZ1bmRhZG1pbi5mdW5kY29kZSI6IkxpbmtHcm91cCIsImxpbmtncm91cC5mdW5kYWRtaW4uY2xpZW50aWQiOiJMaW5rR3JvdXAiLCJzY29wZSI6WyJsaW5rZ3JvdXAuZnVuZGFkbWluLm1lbWJlcnNlcnZpY2UuYXBpIiwibGlua2dyb3VwLmZ1bmRhZG1pbi53aWRnZXRkZWNyZWFzZXNlcnZpY2UuYXBpIiwibGlua2dyb3VwLnNlcnZpY2VzLmF1dGhvcml6YXRpb25tYW5hZ2VtZW50c2VydmljZS5hcGkiLCJsaW5rZ3JvdXAuc2VydmljZXMucmVzb3VyY2VtYW5hZ2VtZW50c2VydmljZS5hcGkiXX0.G7gmAzbXBHbWz_BGzdlsTNOTwjROk2ZBo4ccx3PJ-2H0vPu3A4pvk3_ZjHU0EoLQnyMFcGV2vQqCiZ9Rm_J4E0BU1eBi0YWREI04NBL7OkELM3urWcfDEq9soKkBNML3QzLpZmcSIIrbJDJaWLb_hsmWs7_VObagSAD0pIDNR6D56HizWyA91WduRSHQUJ0WInBHjcCmOG2C49souqCHb9_Z39lXaxJm6jzB2flt2Cm-30QOPviez_de98hS0vcN6rQVByGNdCNjBHXRxxPCGmjXFLgUCe38ZsZt6yKQvJ0S3bEsWVLr0NU6FjHssOd7xOdLSpyBPLj3WOc7Vpw5bg" } };
            //return new Dictionary<string, object> { { "Authorization", GenerateMemberServiceToken(Settings.AuthKey, Settings.AuthorizationUrl, Settings.MemberServiceTokenRequest).Result } };
        }

        public static IDictionary<string, object> GetInvalidUserToken()
        {
            return new Dictionary<string, object> { { "Authorization", "Bearer jak722jayqoanhsget182" } };
        }

        public static IDictionary<string, object> GetResourceOwnerMemberServiceUserToken()
        {
            return new Dictionary<string, object> { { "Authorization", GenerateMemberServiceToken(Settings.ResourceOwnerFlowAuthKey, Settings.AuthorizationUrl, Settings.ResourceOwnerFlowMemberServiceTokenRequest).Result } };
        }

        public static IDictionary<string, object> GetMemberServiceUserTokenforHostPlus()
        {
            return new Dictionary<string, object> { { "Authorization", GenerateMemberServiceToken(Settings.AuthkeyforHostplus, Settings.AuthorizationUrlhostplus, Settings.MemberServiceTokenRequestforHostplus).Result } };
        }
    }
}
