﻿using Dsf.TestFramework.Configuration.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Dsf.VCOP.ServiceTests.Setup
{
    public static class Settings
    {

        public static string AuthorizationUrl => nameof(AuthorizationUrl).GetValueFromAppSettings();
        public static string AuthorizationUrlhostplus => nameof(AuthorizationUrlhostplus).GetValueFromAppSettings();

        public static string AuthKey => nameof(AuthKey).GetValueFromAppSettings();

        public static string ConnectionString => nameof(ConnectionString).GetValueFromAppSettings();

        public static string MemberServiceTokenRequest => nameof(MemberServiceTokenRequest).GetValueFromAppSettings();

        public static string ResourceOwnerFlowMemberServiceTokenRequest => nameof(ResourceOwnerFlowMemberServiceTokenRequest).GetValueFromAppSettings();
        public static string ResourceOwnerFlowAuthKey => nameof(ResourceOwnerFlowAuthKey).GetValueFromAppSettings();

        public static string MemberServiceTokenRequestforHostplus => nameof(MemberServiceTokenRequestforHostplus).GetValueFromAppSettings();
        public static string AuthkeyforHostplus => nameof(AuthkeyforHostplus).GetValueFromAppSettings();

        public static string AuthkeyforClubplus => nameof(AuthkeyforClubplus).GetValueFromAppSettings();
        public static string AuthorizationUrlClubplus => nameof(AuthorizationUrlClubplus).GetValueFromAppSettings();
        public static string MemberServiceTokenRequestforClubplus => nameof(MemberServiceTokenRequestforClubplus).GetValueFromAppSettings();

    }
}
