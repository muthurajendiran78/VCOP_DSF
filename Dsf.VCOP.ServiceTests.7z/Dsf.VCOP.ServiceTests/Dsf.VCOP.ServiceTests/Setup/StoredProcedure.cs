﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Dsf.VCOP.ServiceTests.Setup
{
    class StoredProcedure
    {

        public static string getVerifiedDetails(string userID)
        {

            return "select * from VerifiedIdentity where UserId = (select UserID from[user] where ExternalUserID = '" + userID + "' )";
        }

        public static string getVerificationGUID(int verifiedId)
        {
            return "select VerifiedIdentityGUID from VerifiedIdentity where VerifiedIdentityID=" + verifiedId;
        }

        public static string getExternalUserID(int userID)
        {
            string query = "select ExternalUserID  from [user] where UserID=" + userID;
            return query;
        }

        public static string getIdentityVerificationStatus(int statusId)
        {
            return "select IdentityVerificationStatusCode from IdentityVerificationStatus where IdentityVerificationStatusID=" + statusId;
        }

        public static string getVerifiedIdentityContext(Guid guid)
        {
            return "select * from VerifiedIdentityContext where VerifiedIdentityID=(select VerifiedIdentityID from VerifiedIdentity where VerifiedIdentityGUID='" + guid + "')";
        }

        public static string getApplicationId(int userID)
        {
            string query = "select ExternalUserID  from [user] where UserID=" + userID;
            return query;
        }
    }
}
