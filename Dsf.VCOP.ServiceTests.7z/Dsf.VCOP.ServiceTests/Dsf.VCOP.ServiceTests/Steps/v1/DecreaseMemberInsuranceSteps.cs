﻿using Dsf.MemberInsurance.Service.Messages.v1;
using Dsf.TestFramework.ServiceTests;
using Dsf.TestFramework.ServiceTests.Core;
using Dsf.VCOP.ServiceTests.Setup;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TechTalk.SpecFlow;

namespace Dsf.VCOP.ServiceTests.Steps.v1
{
    [Binding, Scope(Feature = "DecreaseMemberInsuranceSteps v1")]
    public sealed class DecreaseMemberInsuranceSteps
        : GetResponseSteps<UpdateMemberInsuranceDecreaseCover, UpdateMemberInsuranceDecreaseCoverReply>
    {
          

        [Given(@"the request includes valid properties for decrease")]
        public void GivenTheRequestIncludesValidPropertiesForDecrease()
        {
            Request.Properties = Login.GetMemberServiceUserToken();

        }

        [Then(@"the response is having success message")]
        public void ThenTheResponseIsHavingSuccessMessage()
        {
            Assert.AreEqual(Response.IsSuccess, true);
        }

    }
}
