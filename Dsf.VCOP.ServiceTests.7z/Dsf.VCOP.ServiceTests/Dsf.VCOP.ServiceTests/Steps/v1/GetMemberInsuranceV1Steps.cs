﻿using Dsf.MemberInsurance.Service.Messages.v1;
using Dsf.TestFramework.ServiceTests.Core;
using Dsf.VCOP.ServiceTests.Setup;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Linq;
using TechTalk.SpecFlow;

namespace Dsf.VCOP.ServiceTests.Steps.v1
{
    [Binding, Scope(Feature = "GetMemberInsurance v1")]
    public class GetMemberInsuranceV1Steps : GetResponseSteps<GetMemberInsurance, GetMemberInsuranceReply>
    {
        [Given(@"the request includes valid properties details")]
        public void GivenTheRequestIncludesValidPropertiesDetails()
        {
            Request.Properties = Login.GetMemberServiceUserToken();
        }
        
        [Then(@"the response is having success message")]
        public void ThenTheResponseIsHavingSuccessMessage()
        {
            Assert.AreEqual(Response.IsSuccess, true);
        }
        [Then(@"the response is having failure message")]
        public void ThenTheResponseIsHavingFailureMessage()
        {
            Assert.AreEqual(Response.IsSuccess, false);
        }

        [Then(@"verify error code is ""(.*)"" and Description is ""(.*)""")]
        public void ThenVerifyErrorCodeIsAndKeyIs(string p0, string p1)
        {
            Assert.AreEqual(p0, Response.Errors.ToArray()[0].Code);
            Assert.AreEqual(p1, Response.Errors.ToArray()[0].Description);
        }

    }
}
