﻿using Dsf.TestFramework.ServiceTests.Core;
using TechTalk.SpecFlow;

namespace Dsf.VCOP.ServiceTests.Steps.v1
{
    [Binding, Scope(Feature = "Service message v1")]
    public sealed class ServiceMessageSteps
        : GetResponseSteps<object, object>
    {
    }
}
